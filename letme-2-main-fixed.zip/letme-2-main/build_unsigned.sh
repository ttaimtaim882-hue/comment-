#!/usr/bin/env bash
# Improved unsigned IPA builder for OGIOS / ThreeOneOSFive
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$ROOT/build"
ARCHIVE="$BUILD_DIR/HYperRegedit-original-identity.xcarchive"
IPA="$BUILD_DIR/HYper-Regedit-Key-Enabled-unsigned.ipa"

echo "Project root: $ROOT"
echo "Looking for Xcode project..."

PROJECT="$ROOT/ThreeOneOSFive.xcodeproj"
if [ ! -d "$PROJECT" ]; then
  echo "ERROR: ThreeOneOSFive.xcodeproj not found in $ROOT" >&2
  exit 1
fi

SCHEME="OGIOS"
echo "Using scheme: $SCHEME"

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

command -v xcodebuild >/dev/null || {
  echo "ERROR: xcodebuild is required. Run this script on macOS with Xcode installed." >&2
  exit 127
}

echo "Building unsigned archive..."
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -archivePath "$ARCHIVE" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  archive

APP_DIR="$ARCHIVE/Products/Applications"
if [ ! -d "$APP_DIR" ]; then
  echo "ERROR: Archive Products/Applications directory missing." >&2
  exit 1
fi

APP=$(find "$APP_DIR" -maxdepth 1 -name '*.app' -type d -print -quit)
if [ -z "$APP" ] || [ ! -d "$APP" ]; then
  echo "ERROR: No .app produced inside the archive. Check xcodebuild output." >&2
  exit 1
fi

echo "Found app: $APP"

# Ensure Patches folder exists and move any .3105 packages into it
PATCH_DIR="$APP/Patches"
mkdir -p "$PATCH_DIR"
shopt -s nullglob
for package in "$APP"/*.3105; do
  mv "$package" "$PATCH_DIR/"
done
shopt -u nullglob

# Normalize Info.plist entries (best-effort)
/usr/libexec/PlistBuddy -c "Set :CFBundleExecutable OGIOS" "$APP/Info.plist" 2>/dev/null || true
/usr/libexec/PlistBuddy -c "Set :CFBundlePackageType APPL" "$APP/Info.plist" 2>/dev/null || true

echo "Packaging IPA..."
mkdir -p "$BUILD_DIR/Payload"
cp -R "$APP" "$BUILD_DIR/Payload/"
(
  cd "$BUILD_DIR"
  /usr/bin/zip -qry "$IPA" Payload
  rm -rf Payload
)

if [ ! -s "$IPA" ]; then
  echo "ERROR: IPA was not created or is empty." >&2
  exit 1
fi

echo "SUCCESS: $IPA"
ls -lh "$IPA"