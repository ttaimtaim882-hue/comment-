# HYperRegedit / OGIOS

هذا هو المشروع الكامل. يحتوي على مشروع Xcode الأصلي، الشاشات، الخدمات، الأصول، ملفات الـpatch، ووحدات العمل الداخلية.

## البنية

- `ThreeOneOSFive/views`: واجهات التطبيق ونظام التصميم.
- `ThreeOneOSFive/helpers`: الخدمات الداخلية مثل إدارة الملفات، المشاريع، التنظيف، التخزين، الأرشفة، وإدارة التفعيل.
- `ThreeOneOSFive/Assets.xcassets`: الأيقونات والصور والخلفيات.
- `ThreeOneOSFive/Patches`: حزم patch المضمنة في التطبيق.
- `ThreeOneOSFive/exploit` و`ThreeOneOSFive/kexploit`: ملفات الدعم الأصلية للمشروع.
- `ThreeOneOSFive.xcodeproj`: مشروع Xcode الكامل.
- `build_unsigned.sh`: بناء IPA غير موقّع على macOS.
- `package_ipa.py`: تغليف .app جاهز إلى IPA (لا يبني المشروع).

## التفعيل

المفتاح المقبول هو:

```text
WINNER
```

يحفظ التفعيل في Keychain على الجهاز.

## البناء

يتطلب البناء جهاز macOS مع Xcode.

```bash
chmod +x build_unsigned.sh
./build_unsigned.sh
```

ثم استخدام GitHub Actions من خلال Workflow البناء الموجود في `.github/workflows/objective-c-xcode.yml`.

## تغليف IPA من .app جاهز

إذا كان لديك مجلد يحتوي على تطبيق واحد (.app) فقط:

```bash
python3 package_ipa.py /path/to/folder/with/one.app output.ipa
```

يجب أن يحتوي المجلد على تطبيق iOS واحد فقط، وإلا سيظهر الخطأ:

```
ValueError: Choose a project_dir containing exactly one iOS application
```
